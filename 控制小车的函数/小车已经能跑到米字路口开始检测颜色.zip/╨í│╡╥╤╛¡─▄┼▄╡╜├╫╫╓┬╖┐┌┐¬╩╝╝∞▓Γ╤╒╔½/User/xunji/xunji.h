#ifndef _XUNJI_H
#define _XUNJI_H

#include "stm32f10x.h"

void xunji(void);

#endif /*  _XUNJI_H  */


