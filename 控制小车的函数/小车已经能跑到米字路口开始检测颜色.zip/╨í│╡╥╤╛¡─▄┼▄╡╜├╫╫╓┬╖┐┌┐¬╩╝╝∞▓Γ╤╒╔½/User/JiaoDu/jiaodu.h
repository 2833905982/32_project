#ifndef _JIAODU_H
#define _JIAODU_H


#include "stm32f10x.h"

void turn_left(u16 tt);
void turn_right(u16 tt);
void qian_jin(void);
void stop(void);
void houtui(void);

#endif /*  _JIAODU_H  */


